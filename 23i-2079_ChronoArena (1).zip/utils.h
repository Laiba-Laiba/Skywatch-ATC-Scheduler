#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define MAX_JETS 50
#define AGE_LIMIT 6

// Global shared variables
extern int RR_QUANTUM;  
extern double total_waiting_time;
extern double total_turnaround_time;
extern double total_response_time;
extern int total_jets;


// ANSI Colors
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define CYAN    "\033[1;36m"
#define RESET   "\033[0m"

// Jet structure
typedef struct {
    int pid;
    char name[50];
    int fuel;
    int burst;
    int remaining;
    int queue;
    int quantum_used;
    time_t arrival;
    int age;
    
    // ---- Timing metrics ----
    double start_time;     // first time scheduled
    double completion_time; // when finished
    double waiting_time;
    double turnaround_time;
    double response_time;
    int started; // flag to mark first response time
} Jet;

// Queues
extern Jet Q1[MAX_JETS], Q2[MAX_JETS], Q3[MAX_JETS];
extern int q1_count, q2_count, q3_count;

// Synchronization
extern pthread_mutex_t lock;
extern int running, pause_sim;
extern Jet current;  // the jet currently on the runway


// Logging
extern FILE *log_file;

// Stats
extern int context_switches;
extern float cpu_util;
extern int completed_jets;

// Function declarations
void print_header(void);
void display_queues(void);
void log_event(const char *msg);
void *scheduler(void *arg);
void *jet_generator(void *arg);
void *command_thread(void *arg);
void *fuel_monitor(void *arg);
void *monitor_thread(void *arg);


// Queue operations
void enqueue(Jet *queue, int *count, Jet j);
Jet dequeue(Jet *queue, int *count);
void promote_to_Q1(Jet j);
void promote_to_Q2(Jet j);
void demote_to_Q3(Jet j);

#endif

