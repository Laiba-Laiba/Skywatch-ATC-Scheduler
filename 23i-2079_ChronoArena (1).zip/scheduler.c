#include "utils.h"
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>

Jet current;  // define the global variable


void *scheduler(void *arg) {
    struct timeval start, end;
    gettimeofday(&start, NULL);

    while (running) {
        if (pause_sim) { sleep(8); continue; }

        pthread_mutex_lock(&lock);
       
        int found = 0;

        // Q1 SRTF
        if (q1_count > 0) {
            int idx = 0;
            for (int i = 1; i < q1_count; i++)
                if (Q1[i].fuel < Q1[idx].fuel) idx = i;
            current = Q1[idx];
            for (int i = idx; i < q1_count - 1; i++) Q1[i] = Q1[i + 1];
            q1_count--;
            found = 1;
        }
        // Q2 RR
        else if (q2_count > 0) {
            current = dequeue(Q2, &q2_count);
            found = 1;
        }
        // Q3 FCFS
        else if (q3_count > 0) {
            current = dequeue(Q3, &q3_count);
            found = 1;
        }
        pthread_mutex_unlock(&lock);

        if (!found) { sleep(8); continue; }

        context_switches++;
        char buf[256];
        struct timeval now;
gettimeofday(&now, NULL);
double current_time = now.tv_sec + now.tv_usec / 1000000.0;

// If first run for this jet → mark response time
if (!current.started) {
    current.started = 1;
    current.start_time = current_time;
    current.response_time = current.start_time - current.arrival;
    total_response_time += current.response_time;
}

        sprintf(buf, "[RUNWAY] Allocated to %s (Q%d) [fuel=%d rem=%d]", current.name, current.queue, current.fuel, current.remaining);
       // display_queues();
        printf(GREEN "%s\n" RESET, buf);
        log_event(buf);

        sleep(8);  // simulate runway usage
        current.remaining--;
        current.fuel--;

        // Landing complete
       if (current.remaining <= 0) {
    gettimeofday(&now, NULL);
    double finish_time = now.tv_sec + now.tv_usec / 1000000.0;

    current.completion_time = finish_time;
    current.turnaround_time = current.completion_time - current.arrival;
    current.waiting_time = current.turnaround_time - current.burst;

    total_waiting_time += current.waiting_time;
    total_turnaround_time += current.turnaround_time;
    total_jets++;
    completed_jets++;

    sprintf(buf, "[ATC] Landing complete for %s | WT=%.2f TT=%.2f RT=%.2f", 
            current.name, current.waiting_time, current.turnaround_time, current.response_time);
    printf(CYAN "%s\n" RESET, buf);
    log_event(buf);
}

        // Emergency
        else if (current.fuel <= 3 && current.queue != 1) {
            sprintf(buf, "[ATC] Emergency for %s (fuel=%d) -> moved to Q1", current.name, current.fuel);
            printf(RED "%s\n" RESET, buf);
            log_event(buf);
            current.queue = 1;
            promote_to_Q1(current);
        }
        // RR quantum handling
        else if (current.queue == 2) {
            current.quantum_used++;
            if (current.quantum_used >= RR_QUANTUM) { current.quantum_used=0; demote_to_Q3(current);}
            else promote_to_Q2(current);
        }
        // Q3 aging
        else if (current.queue == 3) {
            current.age++;
            if (current.age >= AGE_LIMIT) { current.age=0; promote_to_Q2(current);
                sprintf(buf, "[ATC] Aging: %s promoted from Q3 → Q2", current.name);
                printf(YELLOW "%s\n" RESET, buf); log_event(buf);
            } else demote_to_Q3(current);
        }

        pthread_mutex_lock(&lock);
        for(int i=0;i<q3_count;i++) Q3[i].age++;
        pthread_mutex_unlock(&lock);

        display_queues();
    }

    gettimeofday(&end, NULL);
    double runtime = (end.tv_sec - start.tv_sec);
    cpu_util = ((float)context_switches / runtime) * 100;
    return NULL;
}

