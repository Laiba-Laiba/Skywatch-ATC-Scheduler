#include "utils.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>   // for gettimeofday()

void *scheduler(void *arg);
void *jet_generator(void *arg);
void *fuel_monitor(void *arg);
void *command_thread(void *arg);  // implement using select() for non-blocking input

int main() {
    struct timeval start, end;
    gettimeofday(&start, NULL); // record simulation start

    print_header();
    log_file = fopen("23i-2079_skywatch_log.txt", "w");
    log_event("[INIT] Operation Skywatch Started.");

    
    
   

    pthread_t gen_t, sched_t, cmd_t, fuel_t, mon_t;
pthread_create(&gen_t, NULL, jet_generator, NULL);
pthread_create(&sched_t, NULL, scheduler, NULL);
pthread_create(&fuel_t, NULL, fuel_monitor, NULL);
pthread_create(&cmd_t, NULL, command_thread, NULL);
pthread_create(&mon_t, NULL, monitor_thread, NULL);

     pthread_join(cmd_t, NULL);
    running = 0;
    
    pthread_cancel(gen_t);
    pthread_cancel(sched_t);
    pthread_cancel(fuel_t);
    pthread_cancel(mon_t);

    fclose(log_file);

    // record end time for CPU utilization
    gettimeofday(&end, NULL);
    double total_time = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
    if (total_time > 0)
        cpu_util = ((double)context_switches / total_time) * 100;
    else
        cpu_util = 0.0;

    printf( "\n\t\t\t\t\t\t\t\t\033[1;3;35m                         [ATC] Simulation terminated\033[0m\n" RESET);
    printf( "\n\t\t\t\t\t\t\t\t\033[1;3;36m Final Stats — Context Switches: %d | CPU Util: %.2f%% | Completed: %d\n\033[0m" RESET,
           context_switches, cpu_util, completed_jets);

    return 0;
}

