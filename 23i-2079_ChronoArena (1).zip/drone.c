#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <sys/select.h>




void *jet_generator(void *arg) {
    srand(2079);
    while (running) {
        sleep(rand()%11 + 15);

        pthread_mutex_lock(&lock);
        int pid = getpid() + rand()%100;
        Jet j;
        j.pid=pid;
        sprintf(j.name,"[UAV-23i-2079-%d]",pid%100);
        j.fuel=rand()%20+5; j.burst=rand()%10+3; j.remaining=j.burst;
        j.queue=2; j.quantum_used=0; j.age=0; j.arrival=time(NULL);
        enqueue(Q2,&q2_count,j);
        pthread_mutex_unlock(&lock);

        char msg[200];
        sprintf(msg,"%s New Jet Created -> Q2 | fuel=%d burst=%d",j.name,j.fuel,j.burst);
        printf(YELLOW "%s\n" RESET, msg); log_event(msg);
    }
    return NULL;
}


void *command_thread(void *arg) {
    char cmd[100];
    while (running) {
        printf(BLUE "> " RESET);
        fflush(stdout);

        if (fgets(cmd, sizeof(cmd), stdin) == NULL) continue;

        int pid, moved;

        // ----------------- Simulation Control -----------------
        if (strncmp(cmd, "exit", 4) == 0) { running = 0; break; }
        else if (strncmp(cmd, "status", 6) == 0) { display_queues(); }
        else if (strncmp(cmd, "pause_sim", 9) == 0) { pause_sim = 1; printf(YELLOW "Simulation paused.\n" RESET); }
        else if (strncmp(cmd, "resume_sim", 10) == 0) { pause_sim = 0; printf(GREEN "Simulation resumed.\n" RESET); }

        // ----------------- Jet Commands -----------------
        else if (strncmp(cmd, "force_emergency", 15) == 0 && sscanf(cmd, "force_emergency %d", &pid) == 1) {
            pthread_mutex_lock(&lock); moved = 0;

            // Q2
            for (int i = 0; i < q2_count; i++) {
                if (Q2[i].pid == pid) 
                { Jet j = Q2[i]; 
                for (int k=i;k<q2_count-1;k++) 
                Q2[k]=Q2[k+1]; 
                q2_count--;
                 j.queue=1; 
                promote_to_Q1(j); 
                moved=1; 
                break; 
                }
            }
            // Q3
            for (int i = 0; i < q3_count && !moved; i++)
             {
                if (Q3[i].pid == pid) 
                { 
                Jet j = Q3[i]; 
                for (int k=i;k<q3_count-1;k++) 
                Q3[k]=Q3[k+1];
                 q3_count--;
                  j.queue=1;
                   promote_to_Q1(j); 
                   moved=1; break; }
            }
            // Current runway jet
           if (!moved && current.pid == pid) {
    current.queue = 1;
    promote_to_Q1(current); // actually insert into Q1
    moved = 1;
    current.pid = -1; // mark runway as free
}
            // force_emergency
if (moved) {
    printf(RED "Jet %d forced to Q1 (Emergency)\n" RESET, pid);
   // show queues immediately
}
            else printf(YELLOW "Jet %d not found.\n" RESET, pid);

            pthread_mutex_unlock(&lock);
        }

        else if (strncmp(cmd, "boost_priority", 14) == 0 && sscanf(cmd, "boost_priority %d", &pid) == 1) {
            pthread_mutex_lock(&lock); moved = 0;

            // Q3 → Q2
            for (int i = 0; i < q3_count; i++) 
            {
                if (Q3[i].pid == pid) 
                { 
                Jet j = Q3[i];
                 for (int k=i;k<q3_count-1;k++) 
                 Q3[k]=Q3[k+1]; 
                 q3_count--;
                  j.queue=2; 
                  promote_to_Q2(j); 
                  moved=1; 
                  break; 
                  }
            }
            // Q2 → Q1
            for (int i = 0; i < q2_count && !moved; i++)
             {
                if (Q2[i].pid == pid) 
                { 
                Jet j = Q2[i]; 
                for (int k=i;k<q2_count-1;k++) 
                Q2[k]=Q2[k+1]; 
                q2_count--; 
                j.queue=1; 
                promote_to_Q1(j); 
                moved=1;
                 break; 
                 }
            }
            // Current runway jet
           if (!moved && current.pid == pid) {
    if (current.queue == 3) { current.queue = 2; promote_to_Q2(current); }
    else if (current.queue == 2) { current.queue = 1; promote_to_Q1(current); }
    current.pid = -1; // optional: free runway
    moved = 1;
}
          if (moved) {
    printf(GREEN "Jet %d boosted to higher queue.\n" RESET, pid);
   
}
            else printf(YELLOW "Jet %d not found.\n" RESET, pid);

            pthread_mutex_unlock(&lock);
        }

        else if (strncmp(cmd, "new_jet", 7) == 0) {
            pthread_mutex_lock(&lock);
            int pid = getpid() + rand()%100;
            Jet j; j.pid=pid; sprintf(j.name,"[UAV-23i-2079-%d]", pid%100);
            j.fuel=rand()%20+5; j.burst=rand()%10+3; j.remaining=j.burst; j.queue=2; j.quantum_used=0; j.age=0;
            enqueue(Q2,&q2_count,j);
            pthread_mutex_unlock(&lock);
            printf(GREEN "[MANUAL] Jet %s added to Q2.\n" RESET, j.name);
            display_queues();
        }

        else printf(YELLOW "Commands: force_emergency <PID>, boost_priority <PID>, new_jet, status, pause_sim, resume_sim, exit\n" RESET);
    }
    return NULL;
}




void *fuel_monitor(void *arg) {
    while (running) {
        pthread_mutex_lock(&lock);
        // Check Q2
        for (int i = 0; i < q2_count; i++) {
            if (Q2[i].fuel <= 3) {
                Jet j = Q2[i];
                for (int k = i; k < q2_count-1; k++) Q2[k] = Q2[k+1];
                q2_count--;
                j.queue = 1;
                promote_to_Q1(j);
                printf(RED "[ATC] Emergency! %s moved from Q2 → Q1\n" RESET, j.name);
                log_event("[EMERGENCY] Jet moved to Q1");
                i--; // Adjust index after removal
            }
        }
        // Check Q3
        for (int i = 0; i < q3_count; i++) {
            if (Q3[i].fuel <= 3) {
                Jet j = Q3[i];
                for (int k = i; k < q3_count-1; k++) Q3[k] = Q3[k+1];
                q3_count--;
                j.queue = 1;
                promote_to_Q1(j);
                printf(RED "[ATC] Emergency! %s moved from Q3 → Q1\n" RESET, j.name);
                log_event("[EMERGENCY] Jet moved to Q1");
                i--;
            }
        }
        pthread_mutex_unlock(&lock);
        sleep(1); // Check every second
    }
    return NULL;
}
