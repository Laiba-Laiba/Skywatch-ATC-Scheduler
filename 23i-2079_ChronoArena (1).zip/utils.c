#include "utils.h"
#include <stdlib.h>
#include <string.h>

// Define global variables
int RR_QUANTUM = 4;  // initialize queue 2 quantum
double total_waiting_time = 0;
double total_turnaround_time = 0;
double total_response_time = 0;
int total_jets = 0;

Jet Q1[MAX_JETS], Q2[MAX_JETS], Q3[MAX_JETS];
int q1_count = 0, q2_count = 0, q3_count = 0;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
int running = 1, pause_sim = 0;

FILE *log_file;

int context_switches = 0;
float cpu_util = 0;
int completed_jets = 0;

// Logging
void log_event(const char *msg) {
    fprintf(log_file, "%s\n", msg);
    fflush(log_file);
}

// Header display
void print_header() 
{
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;36m**********************************************************************************\033[0M"); 
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;36m*                                                                                *\033[0M"); 
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;35m*🛫  Unmanned Aerial Vehicle[UAV]/drone-23i-2079 Operation Skywatch(ATC System)  *\033[0M");
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;36m*                                                                                *\033[0M");
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;32m*                    DEVELOPER : Laiba Nasir (23i-2079)                          *\033[0M");
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;36m*                                                                                *\033[0M");
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;36m**********************************************************************************\033[0m\n");
   
   printf("\n\t\t\t\t\t\t\t\t\033[1;3;35m                     ========= SIMULATION STARTED ======== \033[0m\n");
}

// Display queues
void display_queues() {
    pthread_mutex_lock(&lock);
    printf(YELLOW "\n---------------------------------------\n" RESET);
    printf(CYAN "Current Queue Status:\n" RESET);

    printf(GREEN "Q1 (SRTF - Emergency): " RESET);
    for (int i = 0; i < q1_count; i++)
        printf("[PID:%d fuel:%d] ", Q1[i].pid, Q1[i].fuel);
    printf("\n");

    printf(BLUE "Q2 (RR - Standard): " RESET);
    for (int i = 0; i < q2_count; i++)
        printf("[PID:%d rem:%d] ", Q2[i].pid, Q2[i].remaining);
    printf("\n");

    printf(RED "Q3 (FCFS - Refuel/Standby): " RESET);
    for (int i = 0; i < q3_count; i++)
        printf("[PID:%d rem:%d age:%d] ", Q3[i].pid, Q3[i].remaining, Q3[i].age);
    printf("\n---------------------------------------\n" RESET);
    pthread_mutex_unlock(&lock);
}

// Queue operations
void enqueue(Jet *queue, int *count, Jet j) {
    if (*count < MAX_JETS) {
        queue[*count] = j;
        (*count)++;
    }
}

Jet dequeue(Jet *queue, int *count) {
    Jet j = queue[0];
    for (int i = 1; i < *count; i++)
        queue[i - 1] = queue[i];
    (*count)--;
    return j;
}

void promote_to_Q1(Jet j) 
{  
enqueue(Q1, &q1_count, j); 
}
void promote_to_Q2(Jet j)
 {  
 enqueue(Q2, &q2_count, j); 
 }
void demote_to_Q3(Jet j) 
{ 

enqueue(Q3, &q3_count, j); 

}

