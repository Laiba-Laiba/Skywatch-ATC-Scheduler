                        
                              FILES I HAVE

utils.h: 
    Header file containing global structures, macros, and function prototypes.
utils.c: 
    Contains helper functions for queues, timing, and randomization.
scheduler.c: 
    Implements the ATC scheduling logic for Q1, Q2, and Q3 (SRTF, RR, FCFS).
drone.c: 
    Handles jet (UAV) creation, fuel tracking, and burst/fuel simulation.
monitor.c: 
    Monitors and displays live system performance stats during runtime.
main.c: 
   Entry point; initializes the system, creates threads, and starts the simulation.

                               COMPILATION
To compile all files together, open the terminal in your project folder and run:
     gcc utils.c scheduler.c drone.c main.c monitor.c -o skywatch -lpthread

Explanation:
gcc is the GNU C compiler.
-lpthread links the POSIX threads library for multithreading.
The -o skywatch part creates an executable file named skywatch.
The output executable is named skywatch.
 
                                 RUNNING

Running the Simulation:
Once compiled successfully, start the simulation with:
     ./skywatch

This will start the Operation Skywatch simulation, which automatically creates UAVs (jets), schedules them across multiple queues, and displays live system statistics (like CPU utilization and context switches).
During execution, you can also type commands such as new_jet, status, or exit to interact with the simulation.