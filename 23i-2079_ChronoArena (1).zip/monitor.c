#include "utils.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

void *monitor_thread(void *arg) {
    struct timeval start, now;
    gettimeofday(&start, NULL);

    int prev_context = 0;

    while (running) {
        sleep(15); // show stats every 10 seconds

        gettimeofday(&now, NULL);
        double elapsed = (now.tv_sec - start.tv_sec) + (now.tv_usec - start.tv_usec) / 1000000.0;

        double context_rate = (context_switches - prev_context) / 10.0;
        prev_context = context_switches;

        double avg_wait = (total_jets > 0) ? total_waiting_time / total_jets : 0;
        double avg_turn = (total_jets > 0) ? total_turnaround_time / total_jets : 0;
        double avg_resp = (total_jets > 0) ? total_response_time / total_jets : 0;
        double util = (elapsed > 0) ? ((double)context_switches / elapsed) * 100 : 0;

        printf(YELLOW "\n[MONITOR] Time=%.1fs | Context Rate=%.2f/s | CPU Util=%.2f%% | Avg WT=%.2fs | TT=%.2fs | RT=%.2fs | Completed=%d\n" RESET,
               elapsed, context_rate, util, avg_wait, avg_turn, avg_resp, completed_jets);
        log_event("[MONITOR] System stats updated.");
    }
    return NULL;
}

